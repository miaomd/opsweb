__all__ = ["CpuCard"]
