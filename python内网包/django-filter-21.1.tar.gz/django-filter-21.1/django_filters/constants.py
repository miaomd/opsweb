
ALL_FIELDS = '__all__'


EMPTY_VALUES = ([], (), {}, '', None)
