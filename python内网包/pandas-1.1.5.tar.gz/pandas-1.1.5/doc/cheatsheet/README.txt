The Pandas Cheat Sheet was created using Microsoft Powerpoint 2013.
To create the PDF version, within Powerpoint, simply do a "Save As"
and pick "PDF" as the format.

This cheat sheet was inspired by the RStudio Data Wrangling Cheatsheet[1], written by Irv Lustig, Princeton Consultants[2].

[1]: https://www.rstudio.com/wp-content/uploads/2015/02/data-wrangling-cheatsheet.pdf
[2]: https://www.princetonoptimization.com/
