constants Package
=================

:mod:`constants` Package
------------------------

.. automodule:: MySQLdb.constants
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`CLIENT` Module
--------------------

.. automodule:: MySQLdb.constants.CLIENT
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`CR` Module
----------------

.. automodule:: MySQLdb.constants.CR
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`ER` Module
----------------

.. automodule:: MySQLdb.constants.ER
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`FIELD_TYPE` Module
------------------------

.. automodule:: MySQLdb.constants.FIELD_TYPE
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`FLAG` Module
------------------

.. automodule:: MySQLdb.constants.FLAG
    :members:
    :undoc-members:
    :show-inheritance:
