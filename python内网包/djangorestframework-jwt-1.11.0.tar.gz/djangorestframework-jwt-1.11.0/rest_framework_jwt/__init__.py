# -*- coding: utf-8 -*-

__title__ = 'djangorestframework-jwt'
__version__ = '1.11.0'
__author__ = 'José Padilla'
__license__ = 'MIT'
__copyright__ = 'Copyright 2014-2017 Blimp LLC'

# Version synonym
VERSION = __version__
