# urllib3-secure-extra

Marker library to detect whether urllib3 was installed with the deprecated `[secure]` extra.

Read the [issue on the urllib3 repository](https://github.com/urllib3/urllib3/issues/2680) for more information.
