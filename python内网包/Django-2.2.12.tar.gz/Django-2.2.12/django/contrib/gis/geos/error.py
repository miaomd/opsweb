class GEOSException(Exception):
    "The base GEOS exception, indicates a GEOS-related error."
    pass
