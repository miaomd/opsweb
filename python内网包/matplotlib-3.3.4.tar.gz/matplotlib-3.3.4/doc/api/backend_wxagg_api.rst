
:mod:`matplotlib.backends.backend_wxagg`
========================================

**NOTE** Not included, to avoid adding a dependency to building the docs.

.. .. automodule:: matplotlib.backends.backend_wxagg
..    :members:
..    :undoc-members:
..    :show-inheritance:
