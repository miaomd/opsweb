************************
``matplotlib.offsetbox``
************************

.. inheritance-diagram:: matplotlib.offsetbox
   :parts: 1

.. automodule:: matplotlib.offsetbox
   :members:
   :undoc-members:
   :show-inheritance:
