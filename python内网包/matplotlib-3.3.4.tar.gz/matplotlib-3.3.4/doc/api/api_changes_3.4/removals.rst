Removals
--------
The following deprecated APIs have been removed:
