
:mod:`matplotlib.backends.backend_template`
===========================================

.. automodule:: matplotlib.backends.backend_template
   :members:
   :undoc-members:
   :show-inheritance:
