********************
``matplotlib.dates``
********************

.. inheritance-diagram:: matplotlib.dates
   :parts: 1

.. automodule:: matplotlib.dates
   :members:
   :undoc-members:
   :show-inheritance:
